# EmotionalOS (Replit Edition)

Swift console prototype of EmotionalOS — the human‑centered emotional analytics kernel.
